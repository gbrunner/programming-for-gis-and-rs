# ---------------------------------------------------------------------------
# Chapter12_1.py
# Created by Silas Toms
# 2014 12 25
# ---------------------------------------------------------------------------


def returnfieldnames(fc):
    import arcpy
    fieldnames = [f.name for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldnames

def returnfieldtypes(fc):
    import arcpy
    fieldtypes = [f.type for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldtypes

def returnfieldalias(fc):
    import arcpy
    fieldalias = [f.aliasName for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldalias

def returnfieldbasename(fc):
    import arcpy
    fieldtypes = [f.baseName for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldtypes

def returnfielddomain(fc):
    import arcpy
    fielddomains = [f.domain for f in arcpy.ListFields(fc)]
    del arcpy
    return fielddomains

def returnfieldlength(fc):
    import arcpy
    fieldlengths = [f.length for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldlengths

def returnfieldprecision(fc):
    import arcpy
    fieldprecise = [f.precision for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldprecise

def returnfieldscale(fc):
    import arcpy
    fieldscales = [f.scale for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldscales

def returnfieldnullable(fc):
    import arcpy
    fieldnull = [f.isNullable for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldnull

def returnfieldrequired(fc):
    import arcpy
    fieldrequired = [f.required for f in arcpy.ListFields(fc)]
    del arcpy
    return fieldrequired

def returnfielddefaults(fc):
    import arcpy
    fielddef = [f.defaultValue for f in arcpy.ListFields(fc)]
    del arcpy
    return fielddef
    
def returngeometrytype(fc):
    import arcpy
    arcInfo = arcpy.Describe(fc)
    geomtype = arcInfo.shapeType
    del arcpy
    return str(geomtype)
    
def returngeometryname(fc):
    import arcpy
    arcInfo = arcpy.Describe(fc)
    geomname = arcInfo.shapeFieldName
    del arcpy
    return str(geomname)
    
    
def returnprojectioncode(fc):
    import arcpy
    spatial_reference = arcpy.Describe(fc).spatialReference
    proj_code = spatial_reference.projectionCode
    del arcpy
    return  proj_code
    
def returnprojectionname(fc):
    import arcpy
    spatial_reference = arcpy.Describe(fc).spatialReference
    proj_name = spatial_reference.projectionName
    del arcpy
    return  proj_name

def returnsrname(fc):
    import arcpy
    spatial_reference = arcpy.Describe(fc).spatialReference
    proj_name = spatial_reference.name
    del arcpy
    return  proj_name

