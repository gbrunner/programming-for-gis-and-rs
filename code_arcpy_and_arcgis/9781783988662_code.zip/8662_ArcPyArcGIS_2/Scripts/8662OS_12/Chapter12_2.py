# ---------------------------------------------------------------------------
# Chapter12_2.py
# Created by Silas Toms
# 2014 12 25
# ---------------------------------------------------------------------------


import arcpy

folderPath = r"C:\Projects" 
gdbName = "SanFrancisco.gdb"
arcpy.CreateFileGDB_management(folderPath, gdbName)

spatialReference = arcpy.SpatialReference(2227)
fileGDB = r"{0}\{1}".format(folderPath,gdbName)
featureDataset = "Chapter12Results"
arcpy.CreateFeatureDataset_management(fileGDB, featureDataset, spatialReference)

featureClass = "BufferArea"
geometryType = "POLYGON"
featurePath = r"{0}\{1}".format(fileGDB,featureDataset)
arcpy.CreateFeatureclass_management(featurePath, featureClass, geometryType)

fieldName = "STOPID"
fieldAlias = "Bus Stop Identifier"
fieldType = "LONG"
fieldPrecision = 9
featureClassPath = r"{0}\{1}".format(featurePath,featureClass)
arcpy.AddField_management(featureClassPath, fieldName, fieldType, fieldPrecision, "", "", fieldAlias)

fieldName = "AVEPOP"
fieldAlias = "Average Census Population"
fieldType = "FLOAT"
featureClassPath = r"{0}\{1}".format(featurePath,featureClass)
arcpy.AddField_management(featureClassPath, fieldName, fieldType, "", "", "", fieldAlias)