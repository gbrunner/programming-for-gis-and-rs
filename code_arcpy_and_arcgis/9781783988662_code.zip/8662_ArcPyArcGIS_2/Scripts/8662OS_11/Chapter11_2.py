# ---------------------------------------------------------------------------
# Chapter11_2.py
# Created by Silas Toms
# 2014 11 23
# ---------------------------------------------------------------------------

import arcpy

arcpy.CheckOutExtension("Network")
busStops = r'C:\Projects\SanFrancisco.gdb\SanFrancisco\Bus_Stops'
networkDataset = r'C:\Projects\SanFrancisco.gdb\Chapter12Results\street_network'
networkLayer = "streetRoute"
impedance = "Length"
routeLayerFile = "C:\Projects\Layer\{0}_2.lyr".format(networkLayer)
arcpy.arcpy.na.MakeRouteLayer(networkDataset, networkLayer, impedance)
print 'layer created'
sql = "NAME = '71 IB' AND BUS_SIGNAG = 'Ferry Plaza'"
with arcpy.da.SearchCursor(busStops,['SHAPE@', 'STOPID'],sql) as cursor:
    for row in cursor:
        stopShape = row[0]
        print row[1]
        arcpy.na.AddLocations(networkLayer,'Stops', stopShape, "", "")
arcpy.na.Solve(networkLayer,"SKIP")
arcpy.management.SaveToLayerFile(networkLayer,routeLayerFile,"RELATIVE")
print 'finished'
