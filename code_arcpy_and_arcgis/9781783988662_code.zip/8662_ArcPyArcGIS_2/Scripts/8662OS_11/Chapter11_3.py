# ---------------------------------------------------------------------------
# Chapter11_3.py
# Created by Silas Toms
# 2014 09 23
# ---------------------------------------------------------------------------

import arcpy

arcpy.CheckOutExtension("Spatial")
arcpy.env.overwriteOutput = True

busStops = r'C:\Projects\SanFrancisco.gdb\SanFrancisco\Bus_Stops'
sanFranciscoHoods = r'C:\Projects\SanFrancisco.gdb\SanFrancisco\SFFind_Neighborhoods'
sfElevation = r'C:\Projects\SanFrancisco.gdb\sf_elevation'

somaGeometry = []
sql = "name = 'South of Market'"
with arcpy.da.SearchCursor(sanFranciscoHoods,['SHAPE@XY'],sql,None, True) as cursor:
    for row in cursor:
        X = row[0][0]
        Y = row[0][1]
        somaGeometry.append(arcpy.Point(X,Y))
  
somaElev = arcpy.sa.ExtractByPolygon(sfElevation, somaGeometry, "INSIDE")
somaOutput = sfElevation.replace('sf_elevation','SOMA_elev')
somaElev.save(somaOutput)
print 'extraction finished'
 
somaOutput = sfElevation.replace('sf_elevation','SOMA_elev')
 
outTimes = arcpy.sa.Times(somaOutput, 3.28084)
somaOutFeet = sfElevation.replace('sf_elevation','SOMA_feet')
outTimes.save(somaOutFeet)
print 'conversion complete'

with arcpy.da.SearchCursor(sanFranciscoHoods,['SHAPE@'],sql) as cursor:
    for row in cursor:
        somaPoly = row[0]

arcpy.MakeFeatureLayer_management(busStops, 'soma_stops')
arcpy.SelectLayerByLocation_management("soma_stops", "INTERSECT", somaPoly)

outStops = r'C:\Projects\PacktDB.gdb\Chapter11Results\SoMaStops'
arcpy.sa.ExtractValuesToPoints("soma_stops", somaOutFeet,
                      outStops,"INTERPOLATE",
                      "VALUE_ONLY")
print 'points generated'
