# ---------------------------------------------------------------------------
# Chapter9_1.py
# Created by Silas Toms
# 2014 09 23
# ---------------------------------------------------------------------------

import arcpy
bufferDist = 400
mxdPath = r'C:\Projects\MXDs\Chapter9\MapDocument1.mxd'
mxdObject = arcpy.mapping.MapDocument(mxdPath)
dataFrame = arcpy.mapping.ListDataFrames(mxdObject, "Layers")[0]
layersList = arcpy.mapping.ListLayers(mxdObject,"",dataFrame)
busStops = layersList[0]
defQuery = "NAME = '71 IB' AND BUS_SIGNAG = 'Ferry Plaza'"
busStops.definitionQuery = defQuery
idList =[]
with arcpy.da.SearchCursor(busStops,['OID@']) as cursor:
    for row in cursor:
        idList.append(row[0])
for oid in idList:
    newQuery = "OBJECTID = {0}".format(oid)
    print newQuery
    busStops.definitionQuery = newQuery
    with arcpy.da.SearchCursor(busStops,['SHAPE@','STOPID','NAME','BUS_SIGNAG' ,'OID@','SHAPE@XY']) as cursor:
        for row in cursor:
            stopPointGeometry = row[0]
            stopBuffer = stopPointGeometry.buffer(bufferDist)
            