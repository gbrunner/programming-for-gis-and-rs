# ---------------------------------------------------------------------------
# Chapter10_1.py
# Created by Silas Toms
# 2014 10 23
# ---------------------------------------------------------------------------

import arcpy

def nonIntersect(poly1,poly2):
    'returns area of non-intersect between two polygons'
    if poly1.overlaps(poly2) == True:
        return poly1.difference(poly2)
    else:
        return poly1
    
    
def generatePoints(fc, pop,constrant, workspace='in_memory'):
    'generate random points'
    import os,arcpy
    arcpy.CreateRandomPoints_management(workspace, fc, constrant, "", pop, "")
    return os.path.join(workspace, fc)


def generateXLS(datas, sheetName, fileName):
    import xlwt
    workbook = xlwt.Workbook() 
    sheet = workbook.add_sheet(sheetName)
    for YCOUNTER, data in enumerate(datas):
        for XCOUNTER, value in enumerate(data):
            sheet.write(YCOUNTER, XCOUNTER, value)
    workbook.save(fileName)  