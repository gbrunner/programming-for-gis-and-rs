# ---------------------------------------------------------------------------
# Chapter4Examples.py
# Created by Silas Toms
# 2014 04 23
# ---------------------------------------------------------------------------


#First Function

def firstFunction():
    'a simple function returning a string'
    return "My First Function"

def secondFunction(number):
    'this function multiples numbers by 3'
    if type(number) == type(1) or type(number) == type(1.0):
        return number *3


def thirdFunction(number, multiplier=3):
    'this function multiples numbers by a multiplier'
    if type(number) == type(1) or type(number) == type(1.0):
        return number *multiplier

def formatSQL(dataList, sqlTemplate):
    'a function to generate a SQL statement'
    sql = ''
    for count, data in enumerate(dataList):
        if count != len(dataList)-1:
            sql += sqlTemplate.format(data) + ' OR '
        else:
            sql += sqlTemplate.format(data)
    return sql

def formatSQL2(dataList, sqlTemplate, operator=" OR "):
    'a function to generate a SQL statement'
    sql = ''
    for count, data in enumerate(dataList):
        if count != len(dataList)-1:
            
            sql += sqlTemplate.format(*data) + operator
        else:
            sql += sqlTemplate.format(*data)
    return sql


def formatSQLMultiple(dataList, sqlTemplate, operator=" OR "):
    'a function to generate a SQL statement'
    sql = ''
    for count, data in enumerate(dataList):
        if count != len(dataList)-1:
            sql += sqlTemplate.format(*data) + operator
        else:
            sql += sqlTemplate.format(*data)
    return sql


def formatIntersect(features):
    'a function to generate an intersect string'
    formatString = ''
    for count, feature in enumerate(features):
        if count != len(features)-1:
            formatString += feature + " #;"
        else:
            formatString += feature + " #"
    return formatString


def createResultDic(resultFC, key, values):
    import arcpy
    dataDictionary = {}
    fields = [key]
    fields.extend(values)
    with arcpy.da.SearchCursor(resultFC, fields) as cursor:
        for row in cursor:
            busStopID = row[0]
            data = row[1:]
            if busStopID not in dataDictionary.keys():

                dataDictionary[busStopID] = {}

            for counter,field in enumerate(values):
                if field not in dataDictionary[busStopID].keys():
                    dataDictionary[busStopID][field] = [data[counter]]
                else:
                    dataDictionary[busStopID][field].append(data[counter])
    
    return dataDictionary


