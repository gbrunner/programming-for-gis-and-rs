# ---------------------------------------------------------------------------
# Chapter8_3_FixMultipleMXDs.py
# Created by Silas Toms
# 2014 08 23
# ---------------------------------------------------------------------------


import arcpy, glob, os
oldPath = r'C:\Projects\MXDs\Data'
newPath = r'C:\Projects\MXDs\NewData'
folderPath = r'C:\Projects\MXDs\Chapter8'
mxdPathList = glob.glob(os.path.join(folderPath, '*.mxd'))
for path in mxdPathList:   
    mxdObject = arcpy.mapping.MapDocument(path)
    mxdObject.findAndReplaceWorkspacePaths(oldPath,newPath)
    mxdObject.save()


