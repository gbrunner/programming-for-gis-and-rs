Note that an editing issue has left some confusion between the code in the books and the scripts here. 
The File Geodatabase used for these exercises was changed from the PacktDB.gdb to SanFrancisco.gdb.
I apologize for any confusion, and will remove this mistake from the second edition of the book.
Silas Toms
8/10/2015
